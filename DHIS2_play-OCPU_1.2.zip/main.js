document.addEventListener('DOMContentLoaded', function() {
  // Fetch DHIS2 datasets and populate the drop-down menu
  fetchDHIS2Datasets();

  // Add event listener for form submission
  document.getElementById('request-form').addEventListener('submit', function(event) {
    event.preventDefault();
    const method = document.getElementById('method-select').value;
    const endpoint = document.getElementById('endpoint-input').value.trim();
    
    // Adjust the protocol and domain as necessary.
    const fullUrl = `http://149.165.238.109/ocpu${endpoint}`;
    const responseOutput = document.getElementById('response-output');

    responseOutput.textContent = 'Loading...';

    fetch(fullUrl, { method: method })
      .then(response => {
        if (!response.ok) {
          return response.text().then(text => { throw new Error(`${response.status} - ${text}`) });
        }
        return response.text(); // or response.json() if the response is in JSON format
      })
      .then(data => {
        // If the response is JSON, use JSON.stringify to format it, otherwise, display it directly
        responseOutput.textContent = data;
      })
      .catch(error => {
        console.error('Error fetching data from OpenCPU: ', error);
        responseOutput.textContent = `Failed to load response: ${error.message}`;
      });
  });
});

function fetchDHIS2Datasets() {
  // Use DHIS2 API to fetch datasets
  const dhis2ApiUrl = 'https://play.dhis2.org/40.2.1/api/29/dataSets.json';

  fetch(dhis2ApiUrl)
    .then(response => response.json())
    .then(data => {
      const datasetSelect = document.getElementById('dataset-select');
      // Clear existing options
      datasetSelect.innerHTML = '';

      // Populate the drop-down menu with dataset options
      data.dataSets.forEach(dataset => {
        const option = document.createElement('option');
        option.value = dataset.id;
        option.text = dataset.displayName;
        datasetSelect.add(option);
      });
    })
    .catch(error => console.error('Error fetching DHIS2 datasets: ', error));
}
